## Configuration

library(readr)
library(jsonlite)
library(stringr)
library(tibble)
library(lubridate)
library(tidyr)
library(MASS)
library(dplyr)

csv_path  <- "C:/Users/Carlo/Desktop/NLP/With downloads Master csv.csv"
json_path <- "C:/Users/Carlo/Desktop/NLP/master_alligned.json"

scrape_date <- as.Date("2025-12-20")  # data di ottenimento dataset
trim_ks <- c(2)                      
winsor_q <- 0.99                        
curve_days <- 365                       # giorni usati nelle curve 

out_dir <- "C:/Users/Carlo/Desktop/NLP/output"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

stopifnot(file.exists(csv_path), file.exists(json_path))

# save log
log_file <- file.path(out_dir, "analysis_log.txt")
sink(log_file, split = TRUE)




## 1 file merged ################################

message("Loading CSV...")
books <- readr::read_csv(csv_path, show_col_types = FALSE)

message("Loading JSON...")
j <- jsonlite::fromJSON(json_path)

features <- tibble::tibble(
  TextID = as.integer(stringr::str_extract(j$results$book, "\\d+")),
  Concreteness = j$results$Concreteness,
  Arousal = j$results$Arousal,
  first_person_pronouns = j$results$PPronoun$first_person_pronouns,
  third_person_pronouns = j$results$PPronoun$third_person_pronouns,
  subordinate_density = j$results$Phrase$subordinate_density
)

if ("Text#" %in% names(books)) books <- dplyr::rename(books, TextID = `Text#`)
dat <- dplyr::left_join(books, features, by = "TextID")

message("Merged rows: ", nrow(dat))
message("Missing features: ",
        sum(is.na(dat$Concreteness) | is.na(dat$Arousal) |
              is.na(dat$first_person_pronouns) | is.na(dat$third_person_pronouns) |
              is.na(dat$subordinate_density)))


## 2)  dataset #################################################################

dat_nb <- dat %>%
  dplyr::mutate(
    Downloads = as.numeric(Downloads),
    Issued = lubridate::ymd(Issued),
    days_available = as.numeric(scrape_date - Issued),
    days_available = ifelse(is.na(days_available) | days_available <= 0, NA, days_available)
  ) %>%
  dplyr::select(
    Downloads, days_available,
    Concreteness, Arousal,
    first_person_pronouns, third_person_pronouns,
    subordinate_density
  ) %>%
  tidyr::drop_na() %>%
  dplyr::mutate(
    dplyr::across(
      c(Concreteness, Arousal, first_person_pronouns, third_person_pronouns, subordinate_density),
      ~ as.numeric(scale(.x)),
      .names = "{.col}_z"
    ),
    rate = Downloads / days_available
  )

message("NB dataset N: ", nrow(dat_nb))
print(summary(dat_nb$days_available))

terms5 <- c("Concreteness_z","Arousal_z","first_person_pronouns_z",
            "third_person_pronouns_z","subordinate_density_z")


## 3) Functions ########################################################

fit_nb <- function(d, outcome = "Downloads") {
  f <- as.formula(
    paste0(outcome, " ~ ",
           paste(terms5, collapse=" + "),
           " + offset(log(days_available))")
  )
  MASS::glm.nb(f, data = d, control = glm.control(maxit = 200))
}

summ_IRR <- function(m, label, ci_method = c("profile","wald")) {
  ci_method <- match.arg(ci_method)
  co <- coef(m)[terms5]
  p  <- summary(m)$coefficients[terms5, 4]

  ci <- if (ci_method == "profile") {
    suppressMessages(confint(m))[terms5, , drop=FALSE]
  } else {
    confint.default(m)[terms5, , drop=FALSE]
  }

  out <- data.frame(
    model = label,
    term = terms5,
    beta = co,
    IRR = exp(co),
    CI_low = exp(ci[,1]),
    CI_high = exp(ci[,2]),
    pct_change = (exp(co) - 1) * 100,
    p = p,
    row.names = NULL
  )

  out$term <- gsub("_z","", out$term)
  out$term <- gsub("first_person_pronouns","1st_pronouns", out$term)
  out$term <- gsub("third_person_pronouns","3rd_pronouns", out$term)
  out$term <- gsub("subordinate_density","subordination", out$term)

  out
}


## 4) Main Model########################################

m_main <- fit_nb(dat_nb, "Downloads")
message("=== MAIN MODEL SUMMARY ===")
print(summary(m_main))

tab_main <- summ_IRR(m_main, "main", ci_method = "profile")
print(tab_main)


## 5)trim + winsor checks########################################################

tabs <- list(tab_main)

# trim top x
dat_ord <- dat_nb[order(dat_nb$rate, decreasing = TRUE), ]

for (k in trim_ks) {
  d_trim <- dat_ord[-seq_len(k), ]
  m_trim <- fit_nb(d_trim, "Downloads")
  tabs[[paste0("trim_top", k)]] <- summ_IRR(m_trim, paste0("trim_top", k), ci_method = "wald")
}

#winsorize with rate q
q <- quantile(dat_nb$rate, winsor_q, na.rm = TRUE)
cap <- q * dat_nb$days_available
dat_w <- dat_nb
dat_w$Downloads_w <- pmin(dat_w$Downloads, floor(cap))

m_wins <- fit_nb(dat_w, "Downloads_w")
tabs[["winsor_p99"]] <- summ_IRR(m_wins, paste0("winsor_p", winsor_q*100), ci_method = "wald")

tab_rob <- do.call(rbind, tabs)

# rounding for export
tab_rob_round <- tab_rob
tab_rob_round$IRR <- round(tab_rob_round$IRR, 3)
tab_rob_round$CI_low <- round(tab_rob_round$CI_low, 3)
tab_rob_round$CI_high <- round(tab_rob_round$CI_high, 3)
tab_rob_round$pct_change <- round(tab_rob_round$pct_change, 1)
tab_rob_round$p <- signif(tab_rob_round$p, 3)

write.csv(tab_rob_round, file.path(out_dir, "robustness_IRR_table_rounded.csv"), row.names = FALSE)

tab_compact <- tab_rob_round %>%
  dplyr::mutate(IRR_CI = paste0(IRR, " [", CI_low, ", ", CI_high, "]")) %>%
  dplyr::select(model, term, IRR_CI, pct_change, p)

write.csv(tab_compact, file.path(out_dir, "robustness_table_compact.csv"), row.names = FALSE)

message("Saved outputs in: ", out_dir)


## 6) Plots ###############################################


plot_forest_IRR <- function(tab, title="IRR (downloads/day)") {
  df <- tab
  df <- df[order(df$IRR), ]
  par(mar=c(5,10,2,2))
  plot(df$IRR, seq_len(nrow(df)), pch=19, yaxt="n",
       xlab="IRR (per +1 SD)", ylab="",
       xlim=range(c(df$CI_low, df$CI_high)))
  axis(2, at=seq_len(nrow(df)), labels=df$term, las=1)
  segments(df$CI_low, seq_len(nrow(df)), df$CI_high, seq_len(nrow(df)))
  abline(v=1, lty=2)
  title(title)
}

plot_predictive_curve <- function(model, varname, from=-2, to=2, n=200, days=365,
                                  main=NULL, xlab=NULL) {

  x <- seq(from, to, length.out = n)
  grid <- data.frame(
    Concreteness_z = rep(0, n),
    Arousal_z = rep(0, n),
    first_person_pronouns_z = rep(0, n),
    third_person_pronouns_z = rep(0, n),
    subordinate_density_z = rep(0, n),
    days_available = rep(days, n)
  )
  grid[[varname]] <- x

  pr <- predict(model, newdata = grid, type = "link", se.fit = TRUE)
  eta <- pr$fit; se <- pr$se.fit

  mu <- predict(model, newdata = grid, type = "response") 
  rate <- mu / days
  rate_lo <- exp(eta - 1.96*se) / days
  rate_hi <- exp(eta + 1.96*se) / days

  if (is.null(main)) main <- varname
  if (is.null(xlab)) xlab <- varname

  plot(x, rate, type="l", xlab=xlab, ylab="Predicted downloads/day",
       main=main, lwd=2)
  polygon(c(x, rev(x)), c(rate_lo, rev(rate_hi)), border=NA, col=rgb(0,0,0,0.12))
  lines(x, rate, lwd=2)
  abline(v=0, lty=2)
}

# --- plots
png(file.path(out_dir, "forest_main.png"), width=1200, height=700, res=150)
plot_forest_IRR(tab_main, title=paste("Main NB model (scrape:", scrape_date, ")"))
dev.off()



##  log
sink()

writeLines(capture.output(sessionInfo()),
           con = file.path(out_dir, "sessionInfo.txt"))

message("Log scritto in: ", log_file)
