import json
import math
import os
import random
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Optional

import numpy as np
from sklearn.model_selection import RepeatedStratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    roc_auc_score,
    average_precision_score,
)


# CONFIG 

DATA_PATH = "model/src/results_features.json"

FINAL_FEATURE_SET = [
    "PPronoun.first_person_pronouns",
    "PPronoun.third_person_pronouns",
    "Phrase.subordinate_density",
    "Concreteness",
    "Arousal",
]

# Holdout
HOLDOUT_SIZE = 0.20
HOLDOUT_SEED = 100

# Repeated CV on DEV 
SEEDS = [1, 2, 3, 4, 5]
CV_SPLITS = 5
CV_REPEATS = 10

# Inner validation split 
VAL_SIZE = 0.20
N_THRESHOLDS = 201

# Threshold selection policy
THRESHOLD_MODE = "max_f1"        
TARGET_RECALL = 0.70               

# Output
SAVE_THRESHOLD_PATH = "selected_threshold.txt"



# REPRODUCIBILITY

def seed_everything(seed: int):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)



# DATA LOADING

def is_number(x: Any) -> bool:
    return isinstance(x, (int, float)) and not (
        isinstance(x, float) and (math.isnan(x) or math.isinf(x))
    )

def flatten_numeric(obj: Any, prefix: str = "") -> Dict[str, float]:
    out: Dict[str, float] = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            new_prefix = f"{prefix}.{k}" if prefix else str(k)
            out.update(flatten_numeric(v, new_prefix))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            new_prefix = f"{prefix}.{i}" if prefix else str(i)
            out.update(flatten_numeric(v, new_prefix))
    else:
        if is_number(obj):
            out[prefix] = float(obj)
    return out

def load_dataset(path: str) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    rows = data["results"]
    y = np.array(data["meta"]["book_success"], dtype=np.int32)

    flat_rows = []
    for r in rows:
        feats = flatten_numeric(r)
        feats.pop("book", None)
        flat_rows.append(feats)

    feature_names = FINAL_FEATURE_SET[:]
    X = np.array([[d.get(k, 0.0) for k in feature_names] for d in flat_rows], dtype=np.float32)
    return X, y, feature_names



# MODEL

def make_logreg_model() -> Pipeline:
    return Pipeline(
        steps=[
            ("scaler", StandardScaler()),
            ("clf", LogisticRegression(
                class_weight="balanced",
                solver="liblinear",
                max_iter=5000
            )),
        ]
    )



# THRESHOLD SELECTION

@dataclass
class ThresholdChoice:
    threshold: float
    f1: float
    precision: float
    recall: float

def choose_threshold_from_validation(
    y_val: np.ndarray,
    p_val: np.ndarray,
    mode: str = "max_f1",
    target_recall: Optional[float] = None,
    n_thresholds: int = 201,
) -> ThresholdChoice:
    thresholds = np.linspace(0.0, 1.0, n_thresholds)
    best = ThresholdChoice(threshold=0.5, f1=-1.0, precision=0.0, recall=0.0)

    for t in thresholds:
        y_hat = (p_val >= t).astype(int)
        prec = precision_score(y_val, y_hat, zero_division=0)
        rec = recall_score(y_val, y_hat, zero_division=0)
        f1 = f1_score(y_val, y_hat, zero_division=0)

        if mode == "recall_constraint":
            if target_recall is None:
                raise ValueError("target_recall must be set for recall_constraint mode")
            if rec < target_recall:
                continue
            # prefer higher precision, tie-break by f1
            if (prec > best.precision) or (prec == best.precision and f1 > best.f1):
                best = ThresholdChoice(float(t), float(f1), float(prec), float(rec))
        else:
            # max_f1: tie-break by precision, then LOWER threshold (deterministic, less biased high)
            if (f1 > best.f1) or (f1 == best.f1 and prec > best.precision) or (
                f1 == best.f1 and prec == best.precision and t < best.threshold
            ):
                best = ThresholdChoice(float(t), float(f1), float(prec), float(rec))

    # fallback if recall_constraint finds nothing
    if mode == "recall_constraint" and best.f1 < 0:
        return choose_threshold_from_validation(y_val, p_val, mode="max_f1", n_thresholds=n_thresholds)

    return best



# REPORT HELPERS

def summarize(name: str, values: List[float]) -> str:
    a = np.array(values, dtype=float)
    p10, p50, p90 = np.percentile(a, [10, 50, 90])
    return f"{name}: mean={a.mean():.4f} std={a.std():.4f} (p10={p10:.4f} median={p50:.4f} p90={p90:.4f})"

def print_block(title: str, lines: List[str]):
    print("\n" + "=" * 20 + f" {title} " + "=" * 20)
    for ln in lines:
        print(ln)



# MAIN PIPELINE

def main():
    X, y, feature_names = load_dataset(DATA_PATH)
    prevalence = float(y.mean())
    print(f"Samples={len(y)} positives={int(y.sum())} prevalence={prevalence:.4f}")
    print(f"Features ({len(feature_names)}): {feature_names}")

    # held-out split 
    X_dev, X_hold, y_dev, y_hold = train_test_split(
        X, y,
        test_size=HOLDOUT_SIZE,
        stratify=y,
        random_state=HOLDOUT_SEED
    )
    print(f"\nHeld-out split: dev={len(y_dev)} (pos={int(y_dev.sum())}), holdout={len(y_hold)} (pos={int(y_hold.sum())})")

    #DEV and cross V 
    thresholds: List[float] = []
    precs, recs, f1s, accs, baccs = [], [], [], [], []
    pras, rocs = [], []
    cm_sum = np.array([[0, 0], [0, 0]], dtype=int)

    total_runs = len(SEEDS) * CV_SPLITS * CV_REPEATS

    run_id = 0
    for seed in SEEDS:
        seed_everything(seed)
        rskf = RepeatedStratifiedKFold(
            n_splits=CV_SPLITS,
            n_repeats=CV_REPEATS,
            random_state=seed
        )

        for it, (train_idx, test_idx) in enumerate(rskf.split(X_dev, y_dev), start=1):
            run_id += 1

            X_train_full, X_test = X_dev[train_idx], X_dev[test_idx]
            y_train_full, y_test = y_dev[train_idx], y_dev[test_idx]

            # inner train/val split for threshold choice
            inner_seed = seed * 10_000 + it
            X_train, X_val, y_train, y_val = train_test_split(
                X_train_full, y_train_full,
                test_size=VAL_SIZE,
                stratify=y_train_full,
                random_state=inner_seed
            )

            model = make_logreg_model()
            model.fit(X_train, y_train)

            p_val = model.predict_proba(X_val)[:, 1]
            p_test = model.predict_proba(X_test)[:, 1]

            choice = choose_threshold_from_validation(
                y_val=y_val,
                p_val=p_val,
                mode=THRESHOLD_MODE,
                target_recall=TARGET_RECALL if THRESHOLD_MODE == "recall_constraint" else None,
                n_thresholds=N_THRESHOLDS
            )

            t_star = choice.threshold
            thresholds.append(t_star)

            y_hat = (p_test >= t_star).astype(int)

            # threshold-based on outer test fold
            precs.append(float(precision_score(y_test, y_hat, zero_division=0)))
            recs.append(float(recall_score(y_test, y_hat, zero_division=0)))
            f1s.append(float(f1_score(y_test, y_hat, zero_division=0)))
            accs.append(float(accuracy_score(y_test, y_hat)))
            baccs.append(float(balanced_accuracy_score(y_test, y_hat)))
            cm_sum += confusion_matrix(y_test, y_hat)

            # threshold-free on outer test fold
            pras.append(float(average_precision_score(y_test, p_test)))
            rocs.append(float(roc_auc_score(y_test, p_test)) if len(np.unique(y_test)) > 1 else float("nan"))

            if run_id % (CV_SPLITS * CV_REPEATS) == 0:
                print(f"Done dev-CV seed={seed} ({run_id}/{total_runs})")

    print_block(
        "DEV-CV summary (threshold chosen on inner validation)",
        [
            f"Aggregate confusion matrix [[TN FP],[FN TP]]: {cm_sum.tolist()}",
            summarize("Precision", precs),
            summarize("Recall   ", recs),
            summarize("F1       ", f1s),
            summarize("Accuracy ", accs),
            summarize("BalAcc   ", baccs),
            "",
            summarize("PR-AUC   ", pras),
            summarize("ROC-AUC  ", rocs),
            "",
            summarize("Threshold", thresholds),
            f"Baseline PR-AUC (random ~ prevalence): {prevalence:.4f}",
        ],
    )

    # Define global Threshold
    global_thr = float(np.median(np.array(thresholds, dtype=float)))
    print(f"\nChosen GLOBAL threshold from DEV only (median): {global_thr:.4f}")

    # save threshold
    with open(SAVE_THRESHOLD_PATH, "w", encoding="utf-8") as f:
        f.write(f"{global_thr:.6f}\n")
    print(f"Saved threshold to: {SAVE_THRESHOLD_PATH}")

    # evalutation on held out
    final_model = make_logreg_model()
    final_model.fit(X_dev, y_dev)

    p_hold = final_model.predict_proba(X_hold)[:, 1]
    y_hat_hold = (p_hold >= global_thr).astype(int)

    cm_hold = confusion_matrix(y_hold, y_hat_hold)
    prec = precision_score(y_hold, y_hat_hold, zero_division=0)
    rec = recall_score(y_hold, y_hat_hold, zero_division=0)
    f1 = f1_score(y_hold, y_hat_hold, zero_division=0)
    acc = accuracy_score(y_hold, y_hat_hold)
    bacc = balanced_accuracy_score(y_hold, y_hat_hold)
    pr_auc = average_precision_score(y_hold, p_hold)
    roc_auc = roc_auc_score(y_hold, p_hold) if len(np.unique(y_hold)) > 1 else float("nan")

    print_block(
        "HELD-OUT TEST (final, single evaluation; threshold fixed after tuning)",
        [
            f"Threshold used: {global_thr:.4f}",
            f"Confusion matrix [[TN FP],[FN TP]]: {cm_hold.tolist()}",
            f"Precision={prec:.4f} Recall={rec:.4f} F1={f1:.4f}",
            f"Accuracy={acc:.4f} BalAcc={bacc:.4f}",
            f"PR-AUC={pr_auc:.4f} ROC-AUC={roc_auc:.4f}",
        ],
    )


if __name__ == "__main__":
    main()